//
//  ViewController.swift
//  UIAlertController&ActionSheet&AlertView
//
//  Created by Islam Abd El Hakim on 31/10/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnaddAlertView(_ sender: Any) {
        showAlertView()
    }
    
    @IBAction func btnAddActionSheet(_ sender: Any) {
        showActionSheet()
    }
    
    func showAlertView()
    {
        let alert=UIAlertController(title: "title", message: "message", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {action in print("canceled pressed")}))
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: {action in print("ok")}))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: {action in
                                        let txtname=alert.textFields![0]
                                        print("Deleted ,name = \(txtname.text)")}))
       
        alert.addTextField(configurationHandler: {(name )in name.placeholder="Enter Name" })
        //alert.textFields[0].text
        present(alert, animated: true, completion: nil)
        
    }
    func showActionSheet()
    {
        let alert = UIAlertController(title: "title", message: "message", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: nil))
        alert.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)

        
    }
}

