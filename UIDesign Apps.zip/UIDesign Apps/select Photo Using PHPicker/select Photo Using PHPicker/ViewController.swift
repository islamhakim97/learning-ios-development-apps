//
//  ViewController.swift
//  select Photo Using PHPicker
//
//  Created by Islam Abd El Hakim on 01/11/2021.
//

import UIKit
import PhotosUI // For use PHPicker Librarry
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,PHPickerViewControllerDelegate {
  
    @IBOutlet weak var tableview: UITableView!
    var arrPhotos = [UIImage]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableview.delegate=self
        tableview.dataSource=self
        
    }
    
    @IBAction func btnTakePhoto(_ sender: Any) {
        getPhoto()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPhotos.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "photoCell") as! photoTableViewCell
        cell.imgPhoto.image = arrPhotos [indexPath.row]
        return cell
        
    }
    
    func getPhoto()
    {
        var config=PHPickerConfiguration()
        config.filter = .images //.any[.images,.videos,.livephotos]
        config.selectionLimit = 3
        let picker = PHPickerViewController(configuration: config)
        picker.delegate=self
        present(picker, animated: true, completion: nil)
        
    }
    
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        
        for result in results
        {
            dismiss(animated: true, completion: nil)
            result.itemProvider.loadObject(ofClass: UIImage.self, completionHandler: {
                                            (image , error) in
                if let image=image as?UIImage
                {
                    DispatchQueue.main.async {  // for doing operations in app u need to be in main thread so we use dispatchQueue.main.async to get out form background thread to main thread
                        self.arrPhotos.append(image)
                        self.tableview.reloadData()
                    }
                    
                } else {}
                
                
            })
        }
    }
    
    

}

