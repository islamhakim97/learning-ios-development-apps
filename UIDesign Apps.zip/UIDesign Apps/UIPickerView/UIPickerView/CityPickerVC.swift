//
//  CityPickerVC.swift
//  UIPickerView
//
//  Created by Islam Abd El Hakim on 30/10/2021.
//

import UIKit

class CityPickerVC: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    
     let pickerCity=UIPickerView()
    
    var arrCities=["Riyadh","Cairo","Amman","Aden","Baghdad","Gadda"]
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerCity.delegate=self
        pickerCity.dataSource=self
        
        // Do any additional setup after loading the view.
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        <#code#>
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        <#code#>
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        <#code#>
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
