//
//  PickerViewinputTextField.swift
//  UIPickerView
//
//  Created by Islam Abd El Hakim on 30/10/2021.
//

import UIKit

class PickerViewinputTextField: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate ,UITextFieldDelegate{

    @IBOutlet weak var txtfield: UITextField!
   let CityPicker=UIPickerView()
    var arrCities=["Riyadh","Cairo","Amman","Aden","Baghdad","Gadda"]
    var currentIndex=0

    override func viewDidLoad() {
        super.viewDidLoad()
       
        CityPicker.delegate=self
        CityPicker.dataSource=self
        let toolbar=UIToolbar()
        toolbar.sizeToFit()
       let btnbaritem=UIBarButtonItem(title: "Done", style:.done, target: self, action: #selector(closePicker))
        toolbar.setItems([btnbaritem], animated: true)
        
        txtfield.inputView = CityPicker
        txtfield.inputAccessoryView=toolbar
    
        
        // Do any additional setup after loading the view.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrCities.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        currentIndex=row
        return arrCities[row]
    }
    // for put value of selected index in text field
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        txtfield.text=arrCities[row]
    }
    @objc  func closePicker()
    {
        txtfield.text=arrCities[currentIndex] // for approve your selection
        view.endEditing(true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
