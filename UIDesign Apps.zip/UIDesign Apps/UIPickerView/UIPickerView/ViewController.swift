//
//  ViewController.swift
//  UIPickerView
//
//  Created by Islam Abd El Hakim on 30/10/2021.
//

import UIKit

class ViewController: UIViewController ,UIPickerViewDelegate,UIPickerViewDataSource {

    @IBOutlet weak var citiesPicker: UIPickerView!
    @IBOutlet weak var lblshow: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        citiesPicker.dataSource=self
        citiesPicker.delegate=self
    }
    
    var arrCities=["Riyadh","Cairo","Amman","Aden","Baghdad"]

    @IBAction func btngetdata(_ sender:Any) {
        lblshow.text=arrCities[citiesPicker.selectedRow(inComponent: 0)]
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int { //num of cols
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
       
        return arrCities[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return  arrCities.count
    }
    //for showing value of selected row in the current time
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        lblshow.text=arrCities[citiesPicker.selectedRow(inComponent: 0)]
    }
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
       
       return NSAttributedString(string: arrCities[row], attributes:[NSAttributedString.Key.foregroundColor: UIColor.white])
    }
    
}

