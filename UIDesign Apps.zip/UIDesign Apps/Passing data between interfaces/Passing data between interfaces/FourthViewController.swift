//
//  FourthViewController.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 24/10/2021.
//

import UIKit

class FourthViewController: UIViewController {
   var mydata = ""
    @IBOutlet weak var lbl4: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        lbl4.text=mydata
    }
    

   
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      
        if let vc3=segue.destination as?
        thirdViewController
        {
            vc3.mydata="back from 5"
        }
        if let vc1=segue.destination as?firstViewController
        {
            vc1.mydata="back from 5"
        }
        
    }
        
}
    

    

