//
//  thVC.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 28/10/2021.
//

import UIKit

class thVC: UIViewController {

    @IBOutlet weak var thrdlbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        NotificationCenter.default.addObserver(self, selector: #selector(changebackgroundcolor), name: Notification.Name(bgNotificationKey), object: nil)
    }
    
    @objc func changebackgroundcolor()
    {
        print("listen From 3thd")
        view.backgroundColor=#colorLiteral(red: 1, green: 0.1857388616, blue: 0.5733950138, alpha: 1)
    }
    deinit {
        NotificationCenter.default.removeObserver(self)
    }

}
