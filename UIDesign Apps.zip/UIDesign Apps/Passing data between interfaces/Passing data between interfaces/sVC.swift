//
//  sVC.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 28/10/2021.
//

import UIKit

class sVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        /*NotificationCenter.default.addObserver(self, selector: #selector(changebackgroundcolor), name: Notification.Name(bgNotificationKey), object: nil)*/
    }
    @IBOutlet weak var secondlbl: UILabel!
    
    @objc func changebackgroundcolor(_ notification:Notification)
    {
        print("listen From 2nd")
        if let color = notification.object as? UIColor
        {
            view.backgroundColor=color
        }
        
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    

}
