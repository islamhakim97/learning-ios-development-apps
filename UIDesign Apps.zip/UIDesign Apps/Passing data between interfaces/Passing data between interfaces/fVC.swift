//
//  fVC.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 28/10/2021.
//

import UIKit
let bgNotificationKey="com.bambrmj.bgcolorsimo"
let datakey="com.bambrmj.data"


class fVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func btnpushnotification(_ sender: Any) {
        let color=UIColor.red
   
        NotificationCenter.default.post(name: Notification.Name(bgNotificationKey), object: color)
        
    }
    @IBAction func pushdata(_ sender: Any) {
        let data="Hello simo"
        NotificationCenter.default.post(name: Notification.Name(datakey), object: data)
    }
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    /*
    // MARK: - Navigation

     @IBAction func pushdata(_ sender: Any) {
     }
     // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
