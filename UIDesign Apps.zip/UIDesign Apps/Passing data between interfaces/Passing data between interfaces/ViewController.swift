//
//  ViewController.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 21/10/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtfield: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func send(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "secondUId") as! secondUIVC
        let usr=UserData(Name: "asd", age: 22, email: txtfield.text!)
        vc.user=usr
      //  present(vc, animated: true, completion: nil)
       // vc.modalPresentationStyle = .fullScreen
        navigationController?.pushViewController(vc, animated: true)
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage=UIImage()
        navigationItem.titleView=UIImageView(image: UIImage())
    }
}

