//
//  containerVC.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 28/10/2021.
//

import UIKit

class containerVC: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
       // let color = UIColor.red
        let vc = viewControllers?[1] as! sVC
        NotificationCenter.default.addObserver(vc, selector: #selector(vc.changebackgroundcolor), name: Notification.Name(bgNotificationKey), object: nil)
        let vc4 = viewControllers?[3] as! FiVC
        NotificationCenter.default.addObserver(vc4, selector: #selector(vc4.showdata), name:Notification.Name( datakey), object: nil)
    }
    

}
