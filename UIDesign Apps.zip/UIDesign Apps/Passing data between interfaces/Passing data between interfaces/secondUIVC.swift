//
//  secondUIVC.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 21/10/2021.
//

import UIKit

class secondUIVC: UIViewController {
    var user:UserData?
   
    @IBOutlet weak var lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        lbl.text = "\(user?.Name)\(user?.age)\(user?.email)"
        
      
        // Do any additional setup after loading the view.
    }
    
    
    


}
struct UserData
{
    var Name:String
    var age:Int
    var email:String
    
}
