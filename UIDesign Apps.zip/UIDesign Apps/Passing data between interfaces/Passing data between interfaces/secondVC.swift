//
//  secondVC.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 25/10/2021.
//

import UIKit

protocol UserDataDelegate {
    func didselectUserDelegate(name:String,age:Int)
}
class secondVC: UIViewController {
    var userdelegate: UserDataDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
    }
    

    @IBAction func gup(_ sender: Any) {
        userdelegate?.didselectUserDelegate(name: "Islam", age: 23)
        dismiss(animated: true, completion: nil)
    }
    

}
protocol data {
    
}
