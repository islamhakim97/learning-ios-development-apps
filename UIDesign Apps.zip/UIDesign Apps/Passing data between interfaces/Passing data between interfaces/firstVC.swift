//
//  firstVC.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 25/10/2021.
//

import UIKit

    
    

class firstVC: UIViewController,UserDataDelegate{
    func didselectUserDelegate(name: String, age: Int) {
        lblt.text="User name \(name) age :\(age)"
    
    }
     @IBOutlet weak var lbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
   
    @IBOutlet weak var lblt: UILabel!
    

    @IBAction func gud(_ sender: Any) {
        let vc = (self.storyboard?.instantiateViewController(identifier: "userid"))! as secondVC
        vc.userdelegate=self
        present(vc, animated: true, completion: nil)
    }
}
    



