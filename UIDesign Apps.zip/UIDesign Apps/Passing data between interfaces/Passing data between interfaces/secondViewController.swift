//
//  secondViewController.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 24/10/2021.
//

import UIKit

class secondViewController: UIViewController {
    @IBOutlet weak var lbl2: UILabel!
   var mydata=""
    override func viewDidLoad() {
        super.viewDidLoad()
        lbl2.text=mydata
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc3=segue.destination as?
       thirdViewController
        {
            vc3.mydata=lbl2.text!
        }
     
        
    }
    
    @IBAction  func unwindto2(sender:UIStoryboardSegue)
      {
          lbl2.text=mydata
      }
    
}
