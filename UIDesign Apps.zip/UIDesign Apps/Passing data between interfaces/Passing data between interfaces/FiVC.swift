//
//  FiVC.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 28/10/2021.
//

import UIKit

class FiVC: UIViewController {

    @IBOutlet weak var frthlbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        NotificationCenter.default.addObserver(self, selector: #selector(changebackgroundcolor), name: Notification.Name(bgNotificationKey), object: nil)
    }
    
    @objc func changebackgroundcolor()
    {
        print("listen From 4th")
        view.backgroundColor=#colorLiteral(red: 0.7540688515, green: 0.7540867925, blue: 0.7540771365, alpha: 1)
    }
    @objc func showdata(_ notification:Notification)
    {
        if let data = notification.object as? String
        {
            frthlbl.text = data 
        }
    }
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
