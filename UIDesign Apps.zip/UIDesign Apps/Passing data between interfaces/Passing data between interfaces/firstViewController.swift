//
//  firstViewController.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 24/10/2021.
//

import UIKit

class firstViewController: UIViewController {
 var mydata=""
    @IBOutlet weak var lbl1: UILabel!
    var name = "WElData"
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       /* if segue.identifier=="goto2"
        {}
        if segue.destination == secondViewController()
        {}*/
        if let vc2 = segue.destination as? secondViewController{
            vc2.mydata=name
        }
    }

    @IBAction  func unwindto1(sender:UIStoryboardSegue)
      {
          lbl1.text=mydata
      }
}
