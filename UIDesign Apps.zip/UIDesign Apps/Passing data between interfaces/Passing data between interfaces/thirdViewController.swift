//
//  thirdViewController.swift
//  Passing data between interfaces
//
//  Created by Islam Abd El Hakim on 24/10/2021.
//

import UIKit

class thirdViewController: UIViewController {
    var  mydata = ""
    
    @IBOutlet weak var lbl3: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        lbl3.text=mydata
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc4=segue.destination as?
        FourthViewController
        {
            vc4.mydata=lbl3.text!
        }
        if let vc2=segue.destination as?
        secondViewController
        {
            vc2.mydata=lbl3.text!
        }
        
        
    }
   @IBAction func unwindto3(sender:UIStoryboardSegue)
    {
        lbl3.text=mydata
    }
    
   

}
