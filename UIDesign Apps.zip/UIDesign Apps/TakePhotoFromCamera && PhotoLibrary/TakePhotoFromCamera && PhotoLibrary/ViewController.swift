//
//  ViewController.swift
//  TakePhotoFromCamera && PhotoLibrary
//
//  Created by Islam Abd El Hakim on 31/10/2021.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var imgPhoto: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func btntakephoto(_ sender: Any) {
        let alert=UIAlertController(title: "Take Photo From :", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: {action in
            self.getPhoto(type:.camera) // run just on real iphone not simulator
            
        }))
        alert.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: {action in
            self.getPhoto(type: .photoLibrary)
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    func getPhoto(type :UIImagePickerController.SourceType)
    {
        let picker=UIImagePickerController()
        picker.delegate = self
        picker.sourceType=type
        picker.allowsEditing=true
       
        present(picker, animated: true, completion: nil)
        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        dismiss(animated: true, completion: nil)
        guard let image=info[.editedImage]  as? UIImage else
       {
        print("photo not found")
        return
       }
        imgPhoto.image = image
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}

