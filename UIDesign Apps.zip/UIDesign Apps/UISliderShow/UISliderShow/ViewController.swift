//
//  ViewController.swift
//  UISliderShow
//
//  Created by Islam Abd El Hakim on 30/10/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var UIlablel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func sliderdidchanged(_ sender: UISlider) {
        print("value = \(sender.value)")
        UIlablel.font = UIFont(name: UIlablel.font.fontName, size: CGFloat(sender.value))
    }
    
}

