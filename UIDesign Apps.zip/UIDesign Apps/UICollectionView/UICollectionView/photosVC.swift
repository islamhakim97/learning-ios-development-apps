//
//  photosVC.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 17/10/2021.
//

import UIKit

class photosVC: UICollectionView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
