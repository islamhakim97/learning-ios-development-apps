//
//  photosViewController.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 17/10/2021.
//

import UIKit

class photosViewController: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
   
    @IBOutlet weak var collectionview: UICollectionView!
    var arrphotos=[Photo]()
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionview.delegate=self
        collectionview.dataSource=self
        arrphotos.append(Photo(img: [UIImage(named: "img_apple")!,UIImage(named: "img_apple")!,UIImage(named: "img_apple")!,UIImage(named: "img_apple")!], year: "2018"))
        arrphotos.append(Photo(img: [UIImage(named: "img_orange")!,UIImage(named: "img_orange")!], year: "2019"))
          arrphotos.append(Photo(img: [UIImage(named: "img_lemon")!,UIImage(named: "img_apple")!,UIImage(named: "img_mango")!],year:"2020"))
        // Do any additional setup after loading the view.
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return arrphotos.count
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrphotos[section].img.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell=collectionview.dequeueReusableCell(withReuseIdentifier: "photocell", for: indexPath) as! photoCollectionViewCell
        cell.photoimg.image=arrphotos[indexPath.section].img[indexPath.row]
        
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.collectionview.frame.width*0.3, height: self.collectionview.frame.width * 0.3)
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
       
        if kind==UICollectionView.elementKindSectionHeader
        {
            let header=collectionview.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "headeralbum", for: indexPath)
            as!photoCollectionReusableView
        header.lbltxt.text=arrphotos[indexPath.section].year
        header.backgroundColor=#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        header.lbltxt.textColor=#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
            return header
        }
        else
        {
            let footer=collectionview.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "footercell", for: indexPath)
           
            footer.backgroundColor=#colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
            
            
            return footer
        }
        
       
        
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: self.collectionview.frame.size.width, height: 40)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.1
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 1, left: 2, bottom: 1, right:2 )
    }
   
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: collectionview.frame.size.width, height: 10)
    }
    
  

}
struct Photo
{
  let img:[UIImage]
  let year:String
}
