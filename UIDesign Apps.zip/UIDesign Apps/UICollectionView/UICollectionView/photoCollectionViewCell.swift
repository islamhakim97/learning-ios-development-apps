//
//  photoCollectionViewCell.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 17/10/2021.
//

import UIKit

class photoCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var photoimg: UIImageView!
    
}
