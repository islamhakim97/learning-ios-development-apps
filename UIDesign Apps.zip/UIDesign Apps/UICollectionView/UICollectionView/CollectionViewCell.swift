//
//  CollectionViewCell.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 14/10/2021.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var plantImagephoto: UIImageView!
    @IBOutlet weak var lbltxt: UILabel!
    
    func setUp(photo:UIImage , price:Double)
    {
        self.plantImagephoto.image = photo
        self.lbltxt.text="\(price) EGP"
        
    }
    
}
