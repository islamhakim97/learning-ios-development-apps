//
//  ViewController.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 14/10/2021.
//

import UIKit
private let reuseIdentifier = "plantcell"
class ViewController: UIViewController ,UICollectionViewDelegate, UICollectionViewDataSource ,UICollectionViewDelegateFlowLayout{
     
    @IBOutlet weak var collectionview: UICollectionView!
    var plantarr = [Plant]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        collectionview.delegate=self
        collectionview.dataSource=self
        plantarr.append(Plant(image:UIImage(named: "img_orange")!, price: 123))
        plantarr.append(Plant(image:UIImage(named: "img_apple")!, price: 223))
        plantarr.append(Plant(image:UIImage(named: "img_banana")!, price: 144))
        plantarr.append(Plant(image:UIImage(named: "img_lemon")!, price: 150))
        plantarr.append(Plant(image:UIImage(named: "img_orange")!, price: 123))
        plantarr.append(Plant(image:UIImage(named: "img_apple")!, price: 223))
        plantarr.append(Plant(image:UIImage(named: "img_banana")!, price: 144))
        plantarr.append(Plant(image:UIImage(named: "img_lemon")!, price: 150))
        plantarr.append(Plant(image:UIImage(named: "img_banana")!, price: 144))
        plantarr.append(Plant(image:UIImage(named: "img_lemon")!, price: 150))
        plantarr.append(Plant(image:UIImage(named: "img_orange")!, price: 123))
        plantarr.append(Plant(image:UIImage(named: "img_apple")!, price: 223))
        plantarr.append(Plant(image:UIImage(named: "img_banana")!, price: 144))
        plantarr.append(Plant(image:UIImage(named: "img_lemon")!, price: 150))
        plantarr.append(Plant(image:UIImage(named: "img_apple")!, price: 223))
        plantarr.append(Plant(image:UIImage(named: "img_banana")!, price: 144))
        plantarr.append(Plant(image:UIImage(named: "img_lemon")!, price: 150))
        plantarr.append(Plant(image:UIImage(named: "img_orange")!, price: 123))
        plantarr.append(Plant(image:UIImage(named: "img_apple")!, price: 223))
        plantarr.append(Plant(image:UIImage(named: "img_banana")!, price: 144))
        plantarr.append(Plant(image:UIImage(named: "img_lemon")!, price: 150))
        plantarr.append(Plant(image:UIImage(named: "img_banana")!, price: 144))
        plantarr.append(Plant(image:UIImage(named: "img_lemon")!, price: 150))
        plantarr.append(Plant(image:UIImage(named: "img_orange")!, price: 123))
        plantarr.append(Plant(image:UIImage(named: "img_apple")!, price: 223))
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return plantarr.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionview.dequeueReusableCell(withReuseIdentifier:reuseIdentifier, for: indexPath) as! CollectionViewCell
        let plant = plantarr[indexPath.row]
        cell.setUp(photo: plant.image, price: plant.price)
        cell.backgroundColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
        
        // Configure the cell
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.view.frame.width*0.491, height: self.view.frame.width*0.45)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return CGFloat(1)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return CGFloat(0.1)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 1, left: 2, bottom: 1, right: 2)
    }
}

struct Plant
{
    var image:UIImage
   var price:Double
}
