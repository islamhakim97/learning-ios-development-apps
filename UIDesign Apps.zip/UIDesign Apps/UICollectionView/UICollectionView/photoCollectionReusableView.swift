//
//  photoCollectionReusableView.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 17/10/2021.
//

import UIKit

class photoCollectionReusableView: UICollectionReusableView {
    @IBOutlet weak var lbltxt: UILabel!

}
