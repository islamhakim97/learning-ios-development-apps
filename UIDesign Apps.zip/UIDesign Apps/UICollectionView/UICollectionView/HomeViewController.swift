//
//  HomeViewController.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 15/10/2021.
//

import UIKit

class HomeViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var collectionview: UICollectionView!
    
    var arrproducts=[UIImage]()
    var timer=Timer()
    var currentCellIndex=0
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrproducts.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell=collectionview.dequeueReusableCell(withReuseIdentifier: "productcell", for: indexPath)as! productCollectionViewCell
        cell.imageviewcell.image=arrproducts[indexPath.row]
        return cell
    }
    

   
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionview.dataSource=self
        collectionview.delegate=self
        // Do any additional setup after loading the view.
        
        arrproducts.append(UIImage(named: "img_apple")!)
        arrproducts.append(UIImage(named: "img_orange")!)
        arrproducts.append(UIImage(named: "img_mango")!)
        
        
        arrproducts.append(UIImage(named: "img_lemon")!)
        startTimer()
        
    }
    func startTimer()
    {
        print("Start currentCellIndex:\(currentCellIndex)")
        timer = Timer.scheduledTimer(timeInterval: 2.5, target: self,  selector: #selector(moveToNextIndex), userInfo: nil, repeats: true)
    }
    
    @objc func moveToNextIndex()
    {
        print("StartMovecurrentCellIndex:\(currentCellIndex)")
        if(currentCellIndex < arrproducts.count-1)
        {
            currentCellIndex += 1
            
            print("++currentCellIndex:\(currentCellIndex)")
        }
        else
        {
           
            
            currentCellIndex=0
            print("zeroCurrentCellIndex:\(currentCellIndex)")
            
        }
        print("currentCellIndex:\(currentCellIndex)")
        collectionview.scrollToItem(at: IndexPath(item: currentCellIndex, section: 0), at: .centeredHorizontally, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionview.frame.width, height: collectionview.frame.height)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
