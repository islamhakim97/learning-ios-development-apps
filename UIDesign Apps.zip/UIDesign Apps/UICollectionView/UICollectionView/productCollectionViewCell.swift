//
//  productCollectionViewCell.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 15/10/2021.
//

import UIKit

class productCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageviewcell: UIImageView!
    
    
}
