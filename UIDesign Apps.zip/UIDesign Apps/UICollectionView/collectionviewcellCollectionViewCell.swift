//
//  collectionviewcellCollectionViewCell.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 18/10/2021.
//

import UIKit

class collectionviewcellCollectionViewCell: UICollectionViewCell {
   
}
