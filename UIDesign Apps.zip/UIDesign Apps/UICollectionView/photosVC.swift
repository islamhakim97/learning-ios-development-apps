//
//  photosVC.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 18/10/2021.
//

import UIKit

class photosVC: UIViewController ,UITableViewDelegate,UITableViewDataSource{
   
    @IBOutlet weak var tableview: tableview!
     var  arrphotos = [photos]()
   
    override func viewDidLoad() {
      super.viewDidLoad()
        tableview.delegate=self
        tableview.dataSource=self
        // Do any additional setup after loading the view.
        arrphotos.append(photos(name: "Top Rated", photo:[ UIImage(named: "img_apple")!,UIImage(named: "img_apple")!,UIImage(named: "img_apple")!,UIImage(named: "img_apple")!,UIImage(named: "img_apple")!]))
        arrphotos.append(photos(name: "Home", photo:[ UIImage(named: "img_mango")!,UIImage(named: "img_mango")!,UIImage(named: "img_lemon")!,UIImage(named: "img_mango")!,UIImage(named: "img_orange")!]))
        arrphotos.append(photos(name: "MostSold", photo:[ UIImage(named: "img_mango")!,UIImage(named: "img_mango")!,UIImage(named: "img_lemon")!,UIImage(named: "img_mango")!,UIImage(named: "img_orange")!,UIImage(named: "img_mango")!,UIImage(named: "img_lemon")!]))
        arrphotos.append(photos(name: "Offers", photo:[ UIImage(named: "img_mango")!,UIImage(named: "img_mango")!,UIImage(named: "img_lemon")!,UIImage(named: "img_mango")!,UIImage(named: "img_orange")!,UIImage(named: "img_mango")!,UIImage(named: "img_lemon")!]))
        arrphotos.append(photos(name: "Office", photo:[ UIImage(named: "img_mango")!,UIImage(named: "img_mango")!,UIImage(named: "img_lemon")!,UIImage(named: "img_mango")!,UIImage(named: "img_orange")!,UIImage(named: "img_mango")!,UIImage(named: "img_lemon")!]))
    }
   
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return arrphotos.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "tableviewcell", for: indexPath)
        as! tableViewCellTableViewCell
        cell.setupp(title: arrphotos[indexPath.row].name, image: arrphotos[indexPath.row].photo)
        
        return cell
        
        
    }
   
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
}
struct photos
{
    let name:String
    let photo:[UIImage]
}
