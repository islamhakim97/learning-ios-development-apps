//
//  tableViewCellTableViewCell.swift
//  UICollectionView
//
//  Created by Islam Abd El Hakim on 18/10/2021.
//

import UIKit

class tableViewCellTableViewCell: UITableViewCell,UICollectionViewDelegate,UICollectionViewDataSource ,UICollectionViewDelegateFlowLayout{
 
    
    
    @IBOutlet weak var lbltxt: UILabel!
   
    @IBOutlet weak var collectionview: UICollectionView!
    var arrproducts = [product]()
    var title=""
    var photosarr=[UIImage]()
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionview.delegate=self
        collectionview.dataSource=self
        
        // Initialization code
    
   
  
   
        
    }
    func setupp(title:String,image:[UIImage])
    {
        self.lbltxt.text=title
        self.photosarr=image
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photosarr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell=collectionview.dequeueReusableCell(withReuseIdentifier: "collectionviewcell", for: indexPath) as! productphotocvc
       
        cell.productimg.image=photosarr[indexPath.row]
        return cell
        
        
    }

    
    


    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.collectionview.frame.width*0.3, height: self.collectionview.frame.height*0.3)
    }
    

}
struct product {
    var title:String
    var img:[UIImage]
}
