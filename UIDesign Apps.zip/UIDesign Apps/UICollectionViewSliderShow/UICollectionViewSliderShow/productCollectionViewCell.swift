//
//  productCollectionViewCell.swift
//  UICollectionViewSliderShow
//
//  Created by Islam Abd El Hakim on 16/10/2021.
//

import UIKit

class productCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var productImage: UIImageView!
    
}
