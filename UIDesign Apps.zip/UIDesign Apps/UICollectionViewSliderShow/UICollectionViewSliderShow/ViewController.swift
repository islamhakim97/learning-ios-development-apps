//
//  ViewController.swift
//  UICollectionViewSliderShow
//
//  Created by Islam Abd El Hakim on 16/10/2021.
//

import UIKit

class ViewController: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    @IBOutlet weak var pageController: UIPageControl!
    @IBOutlet weak var collectionView: UICollectionView!
    var productarr=[UIImage(named: "img_orange")!,UIImage(named: "img_apple")!,UIImage(named: "img_mango")!,UIImage(named: "img_lemon")!]
    
    
    var timer=Timer()
    var currentCellIndex=0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       collectionView.delegate=self
       collectionView.dataSource=self
        pageController.numberOfPages=productarr.count
        startTimer()
    }
    func startTimer()
    {
        print("start currentCellIndex\(currentCellIndex)")
        timer=Timer.scheduledTimer(timeInterval: 2.5, target: self, selector: #selector(moveToNextIndex), userInfo: nil, repeats: true)
    }
    @objc func moveToNextIndex()
    {
        print("Start End currentCellIndex\(currentCellIndex)")
        currentCellIndex += 1
        collectionView.scrollToItem(at:IndexPath(item: currentCellIndex, section: 0), at: .centeredHorizontally, animated: true)
        print("End currentCellIndex\(currentCellIndex)")
        pageController.currentPage = currentCellIndex
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return productarr.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "productCell", for: indexPath)as! productCollectionViewCell
        cell.productImage.image = productarr[indexPath.row]
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width:self.collectionView.frame.width, height: self.collectionView.frame.height)
    }

}

