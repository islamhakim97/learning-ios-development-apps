//
//  HomeViewController.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 09/10/2021.
//

import UIKit

class HomeViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate{
   
    
    
    @IBOutlet weak var tableview: UITableView!
    var Fruitarr=[Fruit]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.dataSource=self
        tableview.delegate=self
        Fruitarr.append(Fruit.init(fruitName: "Orange", price: 12, Description: "Good Fruit ,popular for people ,winter", img: UIImage(named: "img_orange")!))// must initialaize in constructor fpr fill array with values
        Fruitarr.append(Fruit.init(fruitName: "banana", price: 12.5, Description: "Good Fruit ,popular for people ,winter", img: UIImage(named: "img_banana")!))// must initialaize in constructor fpr fill array with values
        Fruitarr.append(Fruit.init(fruitName: "lemon", price: 14, Description: "Good Fruit ,popular for people ,summer", img: UIImage(named: "img_lemon")!))// must initialaize in constructor fpr fill array with values
        Fruitarr.append(Fruit.init(fruitName: "apple", price: 15, Description: "Good Fruit ,popular for people ,winter", img: UIImage(named: "img_apple")!))// must initialaize in constructor fpr fill array with values
        Fruitarr.append(Fruit.init(fruitName: "papaya", price: 13.5, Description: "Good Fruit ,popular for people ,winter", img: UIImage(named: "img_papaya")!))
        
        // must initialaize in constructor fpr fill array with values
       Fruitarr.append(Fruit.init(fruitName: "Orange", price: 12, Description: "Good Fruit ,popular for people ,winter", img: UIImage(named: "img_orange")!))// must initialaize in constructor fpr fill array with values
        Fruitarr.append(Fruit.init(fruitName: "Orange", price: 12, Description: "Good Fruit ,popular for people ,winter", img: UIImage(named: "img_orange")!))// must initialaize in constructor fpr fill array with values
        Fruitarr.append(Fruit.init(fruitName: "Orange", price: 12, Description: "Good Fruit ,popular for people ,winter", img: UIImage(named: "img_orange")!))// must initialaize in constructor fpr fill array with values
        
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Fruitarr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableview.dequeueReusableCell(withIdentifier:"cell" )as! FruitTableViewCell
        // as![***FruitTableViewCell****] مهمه مهمه مهمه very important so u can use functions of Fruit table view cell class
        let data=Fruitarr[indexPath.row]
        cell.setupcell(name: data.fruitName, price: data.price, description: data.Description, photo: data.img)
        cell.btnAddToFavourite.tag=indexPath.row
        cell.btnAddToFavourite.addTarget(self, action:#selector(addToFavourite(sender:)) , for: .touchUpInside)
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Selected : \(indexPath.row)")
        
    }
    @objc  // don not forget (@objc)
    func addToFavourite(sender:UIButton)
    {
        print("button index = \(sender.tag)")
        sender.setImage(UIImage(systemName: "heart.fill"), for: .normal)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
      return 100
    }
   
    
}



struct Fruit {
   let fruitName:String
  let  price:Double
    let Description:String
    let img:UIImage
    
}

