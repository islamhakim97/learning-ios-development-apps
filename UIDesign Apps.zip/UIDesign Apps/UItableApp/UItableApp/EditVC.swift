//
//  EditVC.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 10/10/2021.
//

import UIKit

class EditVC: UIViewController ,UITableViewDataSource,UITableViewDelegate{
    @IBOutlet weak var addbtn: UIButton!
    @IBOutlet weak var textfield: UITextField!
    @IBOutlet weak var tableview: UITableView!
    var arrnames=[String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.dataSource=self
        tableview.delegate=self

        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrnames.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "mycell", for: indexPath)
        cell.textLabel?.text = arrnames[indexPath.row]
        return cell
    }
    

    @IBAction func Editbtn(_ sender: Any) {
        tableview.isEditing = !tableview.isEditing
    }
    @IBAction func addbtn(_ sender: Any) {
       if let txt = textfield.text  //if it contains any value 
       {
        arrnames.append(txt)
        let indxPath = IndexPath(row: arrnames.count-1, section: 0)
        tableview.beginUpdates()
        tableview.insertRows(at:[indxPath], with: .left)
        textfield.text=" "
        tableview.endUpdates()
       }
        
    }
    // move rows -- canMoveRowAt
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    // swap moved rows-- moveRowAt
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        arrnames.swapAt(sourceIndexPath.row, sourceIndexPath.row)
    }
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let deleteAction =  UIContextualAction(style: .destructive, title: "حذف") { action, view, completionhandler in
           
       
            self.arrnames.remove(at: indexPath.row)
            self.tableview.beginUpdates()
            self.tableview.deleteRows(at: [indexPath], with: .automatic)
            self.tableview.endUpdates()
            completionhandler(true)
        }
        
        let favouriteAction=UIContextualAction(style: .normal, title: "اضف للمفضله"){_,_,_ in 
                print("Item Added To Favourite List")
            
        }
        deleteAction.image=UIImage(systemName:"trash")
        favouriteAction.image=UIImage(systemName: "heart")
        favouriteAction.backgroundColor=#colorLiteral(red: 0.3647058904, green: 0.06666667014, blue: 0.9686274529, alpha: 1)
        
            return UISwipeActionsConfiguration(actions: [deleteAction,favouriteAction])
            
       
    
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    

}
