//
//  nodataVC.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 14/10/2021.
//

import UIKit

class nodataVC: UIViewController ,UITableViewDelegate,UITableViewDataSource{
 var arrcities=["Egypt","Amman","kuwit","SuadiArabia"]
    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.dataSource = self
        tableview.dataSource=self
        arrcities.removeAll()
        if (arrcities.count==0)
        {
            //tableview.isHidden=true
            let imageErorrPhoto=UIImageView(frame: CGRect(x: 50, y: 100, width:self.view.frame.width-100 , height: 200))
            imageErorrPhoto.image = UIImage(systemName: "icloud.slash")
            imageErorrPhoto.tintColor=#colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
            self.view.addSubview(imageErorrPhoto)
            let lbltxt = UILabel(frame: CGRect(x: imageErorrPhoto.frame.minX, y:imageErorrPhoto.frame.maxY+15, width: imageErorrPhoto.frame.width, height: 30))
            lbltxt.text="No Data To Display"
            lbltxt.textAlignment = .center // not ( .center )
            self.view.addSubview(lbltxt)
            
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrcities.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cityCell", for: indexPath)
        cell.textLabel?.text=arrcities[indexPath.row]
        return cell
    }
    
}
