//
//  FruitTableViewCell.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 09/10/2021.
//

import UIKit

class FruitTableViewCell: UITableViewCell {
    
    @IBOutlet weak var fruitName: UILabel!
    @IBOutlet weak var btnAddToFavourite: UIButton!
  
    @IBOutlet weak var fruitPrice: UILabel!
    @IBOutlet weak var fruitDescription: UILabel!
    @IBOutlet weak var imageFruit: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
   public func setupcell(name:String,price:Double,description:String,photo:UIImage)
    {
        
        fruitName.text = name
        fruitPrice.text = "\(price) EGP"
        fruitDescription.text = description
        imageFruit.image = photo
    }
    

}
