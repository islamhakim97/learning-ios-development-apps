//
//  pullRefreshVC.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 11/10/2021.
//

import UIKit

class pullRefreshVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
    @IBOutlet weak var tableview: UITableView!
    var arrnum=[String]()
    let refreshControll = UIRefreshControl()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.delegate=self
        tableview.dataSource=self
        // Do any additional setup after loading the view.
        refreshControll.tintColor=#colorLiteral(red: 0.8549019694, green: 0.250980407, blue: 0.4784313738, alpha: 1)
        refreshControll.addTarget(self,action: #selector(getData), for: .valueChanged)
        tableview.addSubview(refreshControll) //add refreshContrll to table view
        
    }
    @objc func getData()
    {
        refreshControll.beginRefreshing()
        arrnum.append("value is :\(arrnum.count)")
        refreshControll.endRefreshing()

        tableview.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrnum.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "numbersCell", for: indexPath)
        cell.textLabel?.text = arrnum[indexPath.row]
        return cell
    }


}
