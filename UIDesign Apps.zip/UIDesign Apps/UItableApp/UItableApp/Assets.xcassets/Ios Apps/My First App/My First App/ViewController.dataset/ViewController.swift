//
//  ViewController.swift
//  My First App
//
//  Created by Islam Abd El Hakim on 06/09/2021.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate{

    @IBOutlet weak var lbltitile: UILabel!
    @IBOutlet weak var txtinput1: UITextField!
    
    @IBOutlet weak var txtinput2: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("viewDidLoad")
        txtinput1.delegate=self
        txtinput2.delegate=self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("viewWillApear")
        
    }
    override func viewDidAppear(_ animated: Bool) {
        print("viewDidApear")
    }
    override func viewWillDisappear(_ animated:Bool)
    {
        print("viewWillDisappear")
    }
    override func viewDidDisappear(_ animatred:Bool)
    {
        print("viewDidDisappear")
    }
    
    @IBAction func loginbtn(_ sender: Any) {
        lbltitile.text="مرحبا بك تم تسجيل الدخول"
    }
    
    @IBAction func newusrbtn(_ sender: Any) {
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //called when return button pressed
        if(textField==txtinput1)
        {
            txtinput2.becomeFirstResponder() //cursor | will move to the password text field
        }
        else
        {
            lbltitile.text="تم تسجيل الدخول"
        }
        return true
    }
    //keyboard == editing
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true) //hiding keyboard
    }
}

