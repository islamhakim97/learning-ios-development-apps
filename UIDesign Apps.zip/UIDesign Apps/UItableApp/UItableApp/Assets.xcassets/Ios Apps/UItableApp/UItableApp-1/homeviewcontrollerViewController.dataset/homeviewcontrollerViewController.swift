//
//  homeviewcontrollerViewController.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 09/10/2021.
//

import UIKit

class homeviewcontrollerViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var productcell: UITableViewCell!
    
    @IBOutlet weak var tableview: UITableView!
    let Fruitarr = [Fruit]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        tableview.delegate=self
        tableview.dataSource=self
        Fruitarr.append(Fruit.init(name: "apple", price: 12, description: "Red Fruit , summer,very delecious", img: <#T##UIImage#>))
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "homecell")
        return cell!
    }
    struct Fruit
    {
        let name :String
        let price :Double
        let description:String
        let img :UIImage
    }
}
