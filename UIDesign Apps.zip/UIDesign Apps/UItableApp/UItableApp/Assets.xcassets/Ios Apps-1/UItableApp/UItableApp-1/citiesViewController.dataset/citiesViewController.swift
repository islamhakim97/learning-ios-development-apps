//
//  citiesViewController.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 12/10/2021.
//

import UIKit

class citiesViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource {
    
    var arrimages=[UIImage(named:"img_apple"),UIImage(named:"img_mango"),UIImage(named:"img_lemon")]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrimages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cityViewCell")as! citiesTableViewCell?
        cell?.imageView?.image = arrimages[indexPath.row]
        return cell!
    }
    

    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.dataSource=self
        tableview.delegate=self
        // Do any additional setup after loading the view.
    }
         
    

  
    

}
