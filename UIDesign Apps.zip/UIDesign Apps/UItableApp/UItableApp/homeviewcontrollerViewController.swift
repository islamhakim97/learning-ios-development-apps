//
//  homeviewcontrollerViewController.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 09/10/2021.
//

import UIKit

class homeviewcontrollerViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    
    @IBOutlet weak var tableview: UITableView!
    var Fruitarr = [Fruit]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        tableview.delegate=self
        tableview.dataSource=self
        Fruitarr.append(Fruit.init(name: "apple", price: 12, description: "Red Fruit , summer,very delecious",
                                   img: UIImage(named: "img_apple")!))
        Fruitarr.append(Fruit.init(name: "banana", price: 15.5, description: "Yellow Fruit , Popular ,very delecious",
                                   img: UIImage(named: "img_banana")!))
        Fruitarr.append(Fruit.init(name: "lemon", price: 13.8, description: "Red Fruit , popular,very delecious",
                                   img: UIImage(named: "img_lemon")!))
        Fruitarr.append(Fruit.init(name: "mango", price: 14, description: "Red Fruit , popular,very delecious",
                                   img: UIImage(named: "img_mango")!))
        Fruitarr.append(Fruit.init(name: "orang", price: 18.5, description: "Red Fruit , summer,very delecious",
                                   img: UIImage(named: "img_orange")!))
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Fruitarr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "homecell")
        let data = Fruitarr[indexPath.row]
        
        return cell!
    }
    struct Fruit
    {
        let name :String
        let price :Double
        let description:String
        let img :UIImage
    }
}
