//
//  ViewController.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 08/10/2021.
//

import UIKit

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource {
   
    
    var  itemsarr=["Islam","Adana","Marwan","Rehap"]

    
    

    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableview.dataSource=self
        tableview.delegate=self
      
    }
    //configure num of rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsarr.count
    }
    
    // configure cells for each row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel!.text = itemsarr[indexPath.row]
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(itemsarr[indexPath.row])
    }
   
}

