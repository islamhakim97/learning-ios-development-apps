//
//  citiesViewController.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 12/10/2021.
//

import UIKit

class citiesViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource {
    
let arrimages=[UIImage(named:"img_dubai"),UIImage(named:"img_amman"),UIImage(named:"img_cairo"),UIImage(named:"img_riyadh")]
   
    

    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.dataSource=self
        tableview.delegate=self
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrimages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cityViewCell")as! citiesTableViewCell?
        cell!.imagePhotoCell.image = arrimages[indexPath.row]
        return cell!
    }
         
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       let photo = arrimages[indexPath.row]
        let photowithratio = photo!.size.width / photo!.size.height
        return tableview.frame.width/photowithratio
    }
  
    

}
