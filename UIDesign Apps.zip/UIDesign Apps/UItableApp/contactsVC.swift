//
//  contactsVC.swift
//  UItableApp
//
//  Created by Islam Abd El Hakim on 11/10/2021.
//

import UIKit

class contactsVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tableview: UITableView!
    let arrSections=["A","I","M"]
    let arrNames=[["Ahmed","Asmaa","Adnan"],["Islam Hakim"],["Marwan","Mohammed"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.delegate=self
        tableview.dataSource=self
        // Do any additional setup after loading the view.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrSections.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrNames[section].count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableview.dequeueReusableCell(withIdentifier: "contactsCell", for: indexPath)
        cell.textLabel?.text = arrNames[indexPath.section][indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return arrSections[section]
    }
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        
        return "Footer Of Section : \(arrSections[section])"
        
    }

   

}
