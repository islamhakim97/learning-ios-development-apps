//
//  hakimViewController.swift
//  NavigationController
//
//  Created by Islam Abd El Hakim on 18/10/2021.
//

import UIKit

class hakimViewController: UIViewController {
    @IBOutlet weak var img: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let lgoutbtn=UIBarButtonItem()
          lgoutbtn.action=#selector(logout)
          lgoutbtn.target=self
          lgoutbtn.image=UIImage(systemName: "power")
        lgoutbtn.tintColor=#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
          navigationItem.rightBarButtonItem=lgoutbtn
        navigationController?.navigationBar.tintColor=#colorLiteral(red: 0.9760960937, green: 1, blue: 0.9567665458, alpha: 1)
        navigationController?.navigationBar.barTintColor=#colorLiteral(red: 0.5741485357, green: 0.5741624236, blue: 0.574154973, alpha: 1)
        let backbtn=UIBarButtonItem()
        backbtn.action=#selector(back)
        backbtn.target=self
        backbtn.image=UIImage(systemName: "backward.fill")
        navigationItem.leftBarButtonItem=backbtn
        navigationController?.navigationBar.prefersLargeTitles=false
        img.image=UIImage(named: "img_hakim")
        navigationController!.navigationBar.titleTextAttributes=[NSAttributedString.Key.font:UIFont(name: "Helvetica-Bold", size:15)!,NSAttributedString.Key.foregroundColor:UIColor.white]
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage=UIImage()
        navigationItem.titleView=UIImageView(image: UIImage(named: "img_hakim"))
    
    }
    @objc func logout()
    {
       print("logout used")
    }
    @objc func back()
    {
        print("backbtnused")
        let vc1=storyboard?.instantiateViewController(identifier: "stb1")
      navigationController?.pushViewController(vc1!, animated: true)
        
    }
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
