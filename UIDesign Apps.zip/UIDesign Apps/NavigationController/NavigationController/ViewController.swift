//
//  ViewController.swift
//  NavigationController
//
//  Created by Islam Abd El Hakim on 18/10/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title="Hello Islam UI"
   
       
     }
    
    

 
    @IBAction func btnNextUI(_ sender: Any) {
        let vcHakim=storyboard?.instantiateViewController(identifier: "hakimUIid")
            navigationController?.pushViewController(vcHakim!, animated: true)
        print("goooo")
     
    }
   
  
    
}

