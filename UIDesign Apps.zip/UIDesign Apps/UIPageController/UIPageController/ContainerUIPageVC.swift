//
//  ContainerUIPageVC.swift
//  UIPageController
//
//  Created by Islam Abd El Hakim on 30/10/2021.
//

import UIKit

class ContainerUIPageVC: UIPageViewController,UIPageViewControllerDelegate,UIPageViewControllerDataSource {
   
    
    var pageController=UIPageControl()
    var Container=[UIViewController]()
    override func viewDidLoad() {
        super.viewDidLoad()
        let vc1 = (storyboard?.instantiateViewController(identifier: "vc1"))!as ViewController
        vc1.pageTitle = "FirstUI"
        vc1.pageDescription = "Description1"
        vc1.pageColor=#colorLiteral(red: 0.5563425422, green: 0.9793455005, blue: 0, alpha: 1)
        let vc2 = (storyboard?.instantiateViewController(identifier: "vc1"))!as ViewController
        vc2.pageTitle = "SecondUI"
        vc2.pageDescription = "Description2"
        vc2.pageColor=#colorLiteral(red: 1, green: 0.5212053061, blue: 1, alpha: 1)
        let vc3 = (storyboard?.instantiateViewController(identifier: "vc1"))!as ViewController
        vc3.pageTitle = "ThirdUI"
        vc3.pageDescription = "Description3"
        vc3.pageColor=#colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        Container.append(vc1)
        Container.append(vc2)
        Container.append(vc3)
        
//        let vc1 = (storyboard?.instantiateViewController(identifier: "vc1"))!
//        let vc2 = (storyboard?.instantiateViewController(identifier: "vc2"))!
//        let vc3 = (storyboard?.instantiateViewController(identifier: "vc3"))!
//        Container.append(vc1)
//        Container.append(vc2)
//        Container.append(vc3)
        delegate=self
        dataSource=self
        if let Vc1 = Container.first{setViewControllers([Vc1], direction: .forward, animated: true, completion: nil)}
       
        addpageControl()// for ---your custom "pageControll"in the bottom of view
        
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
//        guard let currentIndex = Container.firstIndex(of: viewController) else
//        {return nil}
//        let beforeIndex = currentIndex-1
//        guard beforeIndex>=0
//        else{return Container.last}
//       return Container[beforeIndex]
        
        guard let currentIndex = Container.firstIndex(of: viewController)
        else {return nil}
        let afterIndex = currentIndex + 1
        guard afterIndex<Container.count
        else {return Container.first}
        return Container[afterIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
//        guard let currentIndex = Container.firstIndex(of: viewController)
//        else {return nil}
//        let afterIndex = currentIndex + 1
//        guard afterIndex<Container.count
//        else {return Container.first}
//        return Container[afterIndex]
        
        guard let currentIndex = Container.firstIndex(of: viewController) else
        {
            return nil
        }
        
        let beforeIndex = currentIndex-1
        guard beforeIndex>=0
        
        else
        {
            return Container.last
        }
       return Container[beforeIndex]
        
    }
    //Default pageControll
    /*func presentationCount(for pageViewController: UIPageViewController) -> Int {
      return Container.count
    }
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return 0
    }
 */
    // you must remove presentation count&Index (Default pageControll) and make your pageControll
    
    func addpageControl() //your custom page controll
    {
        pageController=UIPageControl(frame: CGRect(x: 0, y:UIScreen.main.bounds.maxY - 75, width: UIScreen.main.bounds.width, height: 50))
        self.pageController.numberOfPages=Container.count
        self.pageController.currentPage = 0
        self.pageController.currentPageIndicatorTintColor=#colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        pageController.tintColor=#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        self.pageController.pageIndicatorTintColor=UIColor.white
        self.view.addSubview(pageController)
        
    }
    // for (your custom page controll)--- in the bottom of view
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        
       
       let pageContentViewcontroller = pageViewController.viewControllers![0]
        self.pageController.currentPage=(Container.count-1) - Container.firstIndex(of: pageContentViewcontroller)! //(size of arr) 2-x = cuurent index in reverse direction
//        self.pageController.currentPage=Container.firstIndex(of: pageContentViewcontroller)!
    }

}
