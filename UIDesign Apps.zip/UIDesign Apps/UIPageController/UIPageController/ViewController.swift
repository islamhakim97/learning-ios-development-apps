//
//  ViewController.swift
//  UIPageController
//
//  Created by Islam Abd El Hakim on 30/10/2021.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    var pageTitle:String?
    var pageDescription:String?
    var pageColor:UIColor?
    override func viewDidLoad() {
        super.viewDidLoad()
        if pageTitle != nil
        {
       lblTitle.text=pageTitle
        }
      if let decription=pageDescription
      {
        lblDescription.text=pageDescription
      }
        if let color=pageColor
        {
        view.backgroundColor=pageColor
        }
       
    }


}

