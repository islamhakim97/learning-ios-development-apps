//
//  ViewController.swift
//  Fonts
//
//  Created by Islam Abd El Hakim on 31/10/2021.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var lbltxt: UILabel!
    @IBOutlet weak var lbltxt3: UILabel!
    
    override func viewDidLoad() {
        // U Can Download Fonts from "fonts.google.com"
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // for each font family --> font name which we use
        // Do not Forget to add Fonts .tff ||otf to info.plist in Fonts provided by application Dictionry
        for family in UIFont.familyNames
        {
            let name = UIFont.fontNames(forFamilyName: family)
            print ("Family Name =\(family) , FontName=\(name)")
            
        }
        lbltxt.font = UIFont(name: "Cairo-Regular", size: 36)
        lbltxt3.font = UIFont(name: "Changa-ExtraLight", size: 30)
    }
    


}

