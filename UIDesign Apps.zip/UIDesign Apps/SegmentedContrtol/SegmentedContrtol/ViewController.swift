//
//  ViewController.swift
//  SegmentedContrtol
//
//  Created by Islam Abd El Hakim on 29/10/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var segmentedControl: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func segdidselected(_ sender: Any) {
        print ("Index = \(segmentedControl.selectedSegmentIndex)")
        print("value=\(segmentedControl.titleForSegment(at: segmentedControl.selectedSegmentIndex) ?? "")")
        
    }
    var canrecieveNotfication=false
    @IBAction func switchdidchanged(_ sender: UISwitch) {
        print("status=\(sender.isOn)")
        canrecieveNotfication=sender.isOn
        
    }
}

