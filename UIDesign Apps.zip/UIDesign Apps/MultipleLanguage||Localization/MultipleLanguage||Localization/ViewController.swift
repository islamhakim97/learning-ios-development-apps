//
//  ViewController.swift
//  MultipleLanguage||Localization
//
//  Created by Islam Abd El Hakim on 02/11/2021.
//

import UIKit
import PhotosUI
class ViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {

    @IBOutlet weak var lblWel: UILabel!
    @IBOutlet weak var btnchangelanguage: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lblWel.text=NSLocalizedString("hello", comment: "Welcome in EG")
        btnchangelanguage.setTitle(NSLocalizedString("chnglang", comment: "For Language Change"), for: .normal)
       // print(Locale.current.languageCode)
        view.semanticContentAttribute = .forceLeftToRight // to force view and its elements with their constraints to be in specific Direction
        
        
    }
    

    @IBAction func btnChangeLang(_ sender: Any) {
       
      // takePhoto() // // to show how lang of permission message changed from ar to en and vice verca "Camera permission (allow to use camera)"
       chngLangShowAlert()
//        let currentLanguage = Locale.current.languageCode // Get System Language
//        let newLanguage=currentLanguage == "en" ? "ar" : "en" //MAke switch for languages "ar and en"
//        UserDefaults.standard.setValue([newLanguage], forKey: "AppleLanguages")
//        exit(0)
    }
    func chngLangShowAlert()
    {
        var Language="ar"
        let alert = UIAlertController(title: "Change Language", message: "Choose Which Language U Want To use", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "English", style: .default, handler: { action in
           Language = "en"
            UserDefaults.standard.setValue([Language], forKey: "AppleLanguages")
            exit(0)
        }))
        alert.addAction(UIAlertAction(title: "Arabic", style: .default, handler: {action in Language="ar"
                                      UserDefaults.standard.setValue([Language], forKey: "AppleLanguages")
                                        exit(0)}
        ))
        alert.addAction(UIAlertAction(title: "French", style: .default, handler: {action in Language="fr"
                                      UserDefaults.standard.setValue([Language], forKey: "AppleLanguages")
                                        exit(0)}))
        
         present(alert, animated: true, completion: nil)
        

    }
    func takePhoto()
    {
        // to show how lang of permission message changed from ar to en and vice verca "Camera permission (allow to use camera)"
        // NOTE:Camera Not Work In Simulator , only works on iphone
        let picker=UIImagePickerController()
        picker.delegate=self
        picker.allowsEditing=true
        picker.sourceType = .camera
       present(picker, animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}

