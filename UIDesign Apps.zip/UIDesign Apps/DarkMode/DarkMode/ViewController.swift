//
//  ViewController.swift
//  DarkMode
//
//  Created by Islam Abd El Hakim on 31/10/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbltxt: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
//        switch traitCollection.userInterfaceStyle {
//        case .dark:
//            lbltxt.text="DarkMode"
//
//        case .light:
//            lbltxt.text="Light Mode"
//
//        default:
//            lbltxt.text="unexpected"
//
//        }
    }


}

